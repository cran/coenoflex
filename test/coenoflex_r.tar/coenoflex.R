coenoflex <- function(name){
    numgrd <- readline(' enter the number of gradients                   [1-10] : ')
    numspc <- readline(' enter the number of species                    [1-500] : ')
    numplt <- readline(' enter the number of plots                      [1-500] : ')
    cmpasy <- readline(' enter the competition asymmetry            [1.00-3.00] : ')
    cmpphy <- readline(' enter the physiological competition coeff. [1.00-3.00] : ')
    skew   <- readline(' enter the skew                             [1.00-4.00] : ')
    hiecon <- readline(' enter the amplitude/abundance correlation  [0.00-1.00] : ')
    yorn   <- readline(' standardize mean total plot abundance?        [y or n] : ')
    if (yorn == 'y') {
      maxtot <- readline(' enter the standard total percent cover        [10-500] : ')
    }
    else {
      maxtot <- 0
    }
    noise  <- readline(' enter the noise in percent                     [0-100] : ')
    slack  <- readline(' enter the slack as a fraction              [0.00-1.00] : ')
    
    grdtyp <- rep(0,numgrd)
    grdlth <- rep(0,numgrd)
    width <- rep(0,numgrd)
    variab <- rep(0,numgrd)
    grdprd <- rep(0,numgrd)
    alphad <- rep(0,numgrd)

    for (i in 1:as.numeric(numgrd)) {
        cat(paste('\n enter gradient type for gradient ',i,'\n'))
        grdtyp[i] <- readline(' enter e for environment or r for resource     [e or r] : ')
        grdlth[i] <- readline(paste(' enter gradient length for gradient ',i,'       [10-1000] : '))
        width[i] <-  readline(' enter the mean width of species amplitudes    [10-100] : ')
        variab[i] <- readline(' enter the variability in percent                [0-50] : ')
        grdprd[i] <- readline(' enter the productivity response in percent     [0-200] : ') 
        alphad[i] <- readline(' enter the trend in alpha-diversity           [0.5-2.0] : ')
    }
    srorf  <- readline(' random or grid species modes                  [r or g] : ')
    autlin <- readline(' enter the autecological function\n : ')
    grdsam <- readline(' enter the list of gradients to sample\n : ')     
    prorf  <- readline(' random or grid plot locations                 [r or g] :  ')
}
